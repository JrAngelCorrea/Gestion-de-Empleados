// Clase que sirve como modelo ya que aloja las variables que utilizaremos y se utilizan en el componente lista-empleados

export class Empleado {

    id:number;
    nombre:String;
    apellido:String;
    email:String;

}
