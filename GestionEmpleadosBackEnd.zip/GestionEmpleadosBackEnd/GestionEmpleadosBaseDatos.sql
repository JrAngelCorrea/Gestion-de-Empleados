CREATE DATABASE controlEmpleados;

USE controlEmpleados;

describe table empleados;

SELECT * FROM EMPLEADOS;

